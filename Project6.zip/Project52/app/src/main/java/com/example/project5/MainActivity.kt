package com.example.project5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var addButton: Button
    private val petList = mutableListOf<PetItem>()
    private lateinit var adapter: PetAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.petRecycler)
        addButton = findViewById(R.id.petButton)

        adapter = PetAdapter(petList)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Load one item at start
        loadRandomPokemon()

        // Add new Pokémon when button is tapped
        addButton.setOnClickListener { loadRandomPokemon() }
    }

    private fun loadRandomPokemon() {
        val randomId = Random.nextInt(1, 1026)
        val apiUrl = "https://pokeapi.co/api/v2/pokemon/$randomId"

        val client = OkHttpClient()
        val request = Request.Builder().url(apiUrl).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { e.printStackTrace() }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { jsonString ->
                    val json = JSONObject(jsonString)
                    val name = json.getString("name")
                    val sprite = json.getJSONObject("sprites").getString("front_default")

                    runOnUiThread {
                        // Add to list
                        petList.add(PetItem(name, sprite))
                        adapter.notifyItemInserted(petList.size - 1)
                        recyclerView.smoothScrollToPosition(petList.size - 1)
                    }
                }
            }
        })
    }
}
