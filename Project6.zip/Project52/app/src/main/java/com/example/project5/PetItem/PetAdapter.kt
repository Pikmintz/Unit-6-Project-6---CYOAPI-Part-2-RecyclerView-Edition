package com.example.project5

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class PetAdapter(
    private val pets: List<PetItem>
) : RecyclerView.Adapter<PetAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val petImage: ImageView = view.findViewById(R.id.rowImage)
        val petName: TextView = view.findViewById(R.id.rowName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = pets[position]

        holder.petName.text = item.name.replaceFirstChar { it.uppercase() }
        Glide.with(holder.itemView)
            .load(item.imageUrl)
            .into(holder.petImage)
    }

    override fun getItemCount(): Int = pets.size
}
