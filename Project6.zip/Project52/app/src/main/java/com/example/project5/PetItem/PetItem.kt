package com.example.project5

data class PetItem(
    val name: String,
    val imageUrl: String
)
